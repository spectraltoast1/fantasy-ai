# Gridiron — Data Contract

> The mapping between what each visual in the prototype **consumes** and the backend
> entities that **supply** it. This is the primary handoff artifact: it lets Claude Code
> wire the real data layer to the UI without guessing.
>
> Companion docs: `README.md` (UI/layout/tokens), and the project's own
> `TECHNICAL_ARCHITECTURE.md` (canonical entity/column definitions).

---

## 0. How to read this contract

- The prototype (`Gridiron - Mobile.dc.html`, `Gridiron - Web.dc.html`) invents its data
  in one place — the `renderVals()` method of each file's logic class. Every visual is
  fed by a flat object. **This contract names, for each visual, the real backend entity
  that should replace the mock.**
- Entity names, grains, and columns below are quoted from `TECHNICAL_ARCHITECTURE.md`.
  Where a column isn't yet named in the architecture, the contract proposes one and marks
  it **(propose)**.
- **The contract sits ABOVE storage.** It describes the *shape of the result set* each
  view needs — not the SQL or the engine. It is identical whether the rows come from
  DuckDB-WASM over parquet (today) or hosted SQLite (later). See §2.

### Legend for flags
- 🟢 **direct** — real entity exists, 1:1 or near-1:1; wiring only.
- 🟡 **derive** — real inputs exist; a front-end/query derivation combines them.
- 🔵 **forward-only** — field exists but is cross-time / POC right now; wire it, gate the live read.
- 🔴 **TODO** — a rule/threshold must be defined before this is correct.

---

## 1. The seam (where data enters the UI)

Per `TECHNICAL_ARCHITECTURE.md`, **all data access lives in `src/queries.js`** and view
components consume plain JS objects — never SQL, never file paths. The prototype already
mirrors this: every screen reads from the object returned by `renderVals()`.

**Implementation guidance:** recreate each prototype screen as a view that receives a
plain object matching the shapes below, and put every read in `queries.js`. Do **not**
scatter data access into the components. This keeps the DuckDB→SQLite move (see §2) a
localized swap.

---

## 2. Storage-independence note (DuckDB-WASM → SQLite)

The current app is client-side DuckDB-WASM over parquet; a hosted SQLite migration is
planned. **This contract is the invariant across that move.** Each visual needs a result
set of the shape described; whichever engine produces it is beneath the seam.

- Today: `queries.js` reads parquet via DuckDB-WASM; `db.js` locates files.
- Later: `queries.js` function bodies become API/SQLite calls; **the shapes below do not
  change**, so no view changes.
- Build the adapter as a clean seam: components depend on the shapes in this contract, not
  on DuckDB or SQLite specifics.

---

## 3. Global concepts (apply across every surface)

| Concept | Prototype behavior | Backend reality | Flag |
|---|---|---|---|
| **Season replay / week switcher** ("AS OF Week 5") | Persistent control in top bar; prototype treats it as visual-only | Real seam. Derived parquets are **tall over `as_of_week`**; `App.jsx` owns `asOfWeek`, threaded via `asOfSlice(table, n)` + `weekCutoff(n)` in `queries.js`. Default = latest; travels back only. | 🟢 |
| **"You" / your team** (violet YOU badge, "YOUR RACE", "On your roster") | Hardcoded to Toast Season | `is_me` resolves via `MY_USERNAME` hardcode in `queries.js` today; architecture plans to bake an `is_me` flag into the `teams` parquet. Use that flag. | 🟡 |
| **Skill positions only** (QB/RB/WR/TE) | Only these appear | Matches: DST/K excluded from all V1 transforms. | 🟢 |
| **League config** (10-tm · PPR · 1QB, lineup slots) | Hardcoded strings | Real: `teams`, `lineup_slots`, `league_settings` parquets drive team count, scoring, slots. Don't hardcode. | 🟢 |
| **Color roles** | Violet `#8b80f9` = brand/accent/you; 5-color set = posture ONLY | Keep this discipline in the real app: posture palette (green/blue/grey/amber/coral) is reserved for the posture read + trend up/down; violet is the unifying brand accent. | — |

---

## 4. Per-surface mapping

### 4.1 Persistent chrome (top bar / bottom nav)
| Visual | Source | Flag |
|---|---|---|
| League switcher (name, "10-tm · PPR · 1QB", record) | `teams` + `league_settings` | 🟢 |
| Week switcher ("AS OF Week 5") | drives `asOfWeek` (§3) | 🟢 |
| Tabs League/Matchups/Teams/Players | client route state | — |

### 4.2 League tab

**Your Race (band)**
| Field | Source | Flag |
|---|---|---|
| Playoff chance % | `bracket_odds.playoff_odds` (as-of-week slice, `is_me` team) | 🟢 |
| Seed N of 10 | `bracket_odds.proj_seed` | 🟢 |
| "top 6 advance" | `league_settings` (playoff cut) | 🟢 |
| Magic number ("Clinch in 4 of next 9") | `bracket_odds.magic_wins` → format string | 🟡 |
| This-week game + win% | `bracket_odds` win prob for the head-to-head (see 4.3) | 🟢 |

**Playoff Picture (list, 10 rows, cut line, trendline)**
| Field | Source | Flag |
|---|---|---|
| Rank-by-odds, playoff % | `bracket_odds.playoff_odds` sorted desc, per as-of-week | 🟢 |
| Playoff line after seed 6 | `league_settings` playoff cut | 🟢 |
| Magic-number subline | `bracket_odds.magic_wins` | 🟡 |
| **Playoff-chance trendline** (sparkline) | `bracket_odds` is tall over `as_of_week` → series of `playoff_odds` for weeks 1..N. Prototype uses synthetic drift; **replace with the real weekly series.** Up/down color = last vs first. | 🟢 |

**Posture Map (quadrant: true rank × standing)**
| Field | Source | Flag |
|---|---|---|
| X-axis (standing / winning↔losing) | current standing from `season` join / `bracket_odds` seed | 🟢 |
| Y-axis (true rec / roster strength) | `true_rank` (record-independent roster strength; `spectrum_pos`) | 🟢 |
| Dot color = posture | **derived** — see §5 posture derivation | 🔴 |

**Positional Talent (league-wide, per position, + waiver strip)**
| Field | Source | Flag |
|---|---|---|
| Per-team bar (Market VOR held at position) | aggregate `market_vor` by (team, position) for the selected position; sum of positive market VOR. (`positional_depth` is the per-team production-VOR analog if you prefer production.) | 🟡 |
| Waiver Wire strip (best available + THIN/STREAMABLE/DEEP) | full player pool / free agents (V1 scope). Best available = top free-agent projection at position; thinness tier = defined rule, §5. | 🟡 |

### 4.3 Matchups tab
| Field | Source | Flag |
|---|---|---|
| Slate rows (each game, both teams, records, proj) | `season` (this-week matchup pairing) + team proj from optimal lineup | 🟢 |
| Win prob per game | `bracket_sim` analytic win prob from team weekly score dists (μ = optimal-lineup projection, σ from `projection_consensus` band) | 🟢 |
| **Watch game** ("swings your seed") | **derive (defined, §5)** — the non-your game whose outcome most changes your `bracket_odds`, if ≥ WATCH_MIN. | 🟡 |
| Matchup detail — head-to-head win prob | same as slate win prob | 🟢 |
| Matchup detail — **Score Range** (team 25–75 band) | team score distribution: sum of starters' `projection_consensus` p25/p50/p75 | 🟢 |
| Matchup detail — per-starter median + 25–75 gauge | `projection_consensus` (p25/p50/p75) per player | 🟢 |
| Starters vs bench split | `season` roster + `lineup_slots` (starters = as-set-in-Sleeper lineup) | 🟢 |

### 4.4 Teams tab
| Field | Source | Flag |
|---|---|---|
| Standings rows (rank, name, owner, record) | `season` join + `teams` | 🟢 |
| **True record** (all-play W-L, e.g. 29-7) | all-play computed inline in `queries.js` (score vs every team every week). **Distinct from `true_rank`** — keep both. | 🟡 |
| Posture chip | derived — §5 | 🔴 |
| Playoff % + **trendline** | `bracket_odds.playoff_odds` + its weekly series (§4.2) | 🟢 |

### 4.5 Team detail
| Field | Source | Flag |
|---|---|---|
| Record / True Rec / Playoff / **Pts/Wk** | `season` (record, all-play, points-for÷games) + `bracket_odds` | 🟡 |
| This-week matchup bar | §4.3 | 🟢 |
| **Positional Depth** (QB/RB/WR/TE, SURPLUS/EVEN/GAP, rank, median tick) | `positional_depth` per (team, position): `starter_value`/`surplus`, `marginal_vor` (gap), `spectrum_pos` vs league, `surplus/adequate/gap` shape | 🟢 |
| **Manager Dossier** button + screen | `manager_dossiers` — see §4.8 | 🟢 |
| **Starters + Bench** rows | `season` roster + `lineup_slots`; starters = actual Sleeper lineup at sync | 🟢 |
| Roster **PROD VOR / MKT VOR toggle** + value + **trend sparkline** | `production_vor` / `market_vor` per player; both tall over week/`snapshot_date` → real weekly series for the sparkline. Delta = last − first. | 🟢 / 🔵 (market forward-only) |

### 4.6 Players tab (table)
| Field | Source | Flag |
|---|---|---|
| Row: pos, name, NFL/team | Sleeper registry + `season` | 🟢 |
| **PROD VOR** column (default sort) | `production_vor` (waiver=0, pool-spread normalized) | 🟢 |
| **MKT VOR** column | `market_vor` | 🔵 forward-only |
| **BULL / BEAR / SIT** sortable columns | `ros_synthesis` bull/bear/situation (1–10 independent axes) | 🟢 |
| Position filter (ALL/QB/RB/WR/TE) | client filter | — |
| **Available (waivers) filter** | free-agent flag on player pool. (Outdated V2 note — wire in V1.) | 🟡 |

### 4.7 Player card
| Field | Source | Flag |
|---|---|---|
| Status ("On your roster" / "Available · waivers" / "Rostered · X") | roster membership vs `is_me` | 🟡 |
| **Value·VOR** — Production + Market trend lines + values + deltas | `production_vor` + `market_vor` weekly series | 🟢 / 🔵 |
| **BUY / HOLD / SELL** lean + why | `market_vor.trade_gap` (= market_vor − production_vor). **Gate the live call:** `is_cross_time` is true now (2025 rosters × 2026 market) — treat as POC until the season rolls to 2026 (§6). | 🔵 |
| **Opportunity** — Quality | `player_signal.quality_rate` (expected fantasy pts per opportunity, league-scored) | 🟢 |
| Opportunity — Volume (share) | `player_signal.opp_g` (opportunity volume) — **(propose)** expose as a share/percentile | 🟡 |
| Opportunity — Trust (direction + reliability) | `player_signal` direction + reliability (Trust axis) | 🟢 |
| Opportunity — Points vs profile (companion) | `player_signal.point_correlation` + `luck` (recent − expected) | 🟢 |
| **ROS Outcome Shape** — bull/bear/situation grades + narrative + signal | `ros_synthesis` grades + prose notes + `confidence`/`confidence_note`; `signal_tier`. Quantitative skeleton in `ros_outcome_shape`. | 🟢 |

### 4.8 Manager Dossier (screen)
**Byte-identical to `manager_dossiers` — the cleanest map in the app.**
| Field | Source | Flag |
|---|---|---|
| Headline | `manager_dossiers.headline` | 🟢 |
| Waiver/FAAB, Trade Tendency, Positional Lean, Roster Construction, Edge/Blind Spot | the matching 5 keys | 🟢 |
| Signal Depth (HIGH/MED/THIN + leagues/seasons/moves counts + note) | `manager_features` (`n_leagues`/`n_seasons`/`n_transactions`, `depth_tier`) + `manager_dossiers.confidence_note` | 🟢 |
| Zero-signal manager | `manager_dossiers.is_zero_signal` → hardcoded "no intel" row (AI skipped) | 🟢 |
| Provenance | `manager_dossiers.model` / `generated_at` | 🟢 |

Guardrails already enforced backend-side (tendencies-not-verdicts, confidence gated on
signal depth) match the prototype copy — keep them.

---

## 5. Posture derivation — 🟡 DEFINED RULE (front-end derivation)

There is **no `posture` column**; posture is the synthesis a manager reads off the
adjacency of **standing** and **true record**. It is computed in the front end from two
values you already have, and rendered as one of five labels:

`Contender · Unlucky · On pace · Riding luck · Rebuild`

### The two axes
- **X — standing** = `bracket_odds.playoff_odds` (0–100). "How you're actually doing."
- **Y — true record** = **all-play win %** = `all_play_wins / (all_play_wins + all_play_losses) * 100`
  (computed inline in `queries.js`; out of 36 at wk5, so it has real spread). "How good
  you've actually been, luck-neutral."

> Why all-play % and not `true_rank`: all-play is continuous (36 games) so the posture-map
> scatter is real, and the standing-vs-performance gap *is* the luck read. `true_rank`
> (VOR roster strength) stays available and is the truer "roster strength" measure — a
> candidate alternate Y-axis, but all-play is the shipped choice for legibility. Both fields
> remain distinct (see §4.4).

### The rule (matches the prototype exactly)
```
gap   = allPlayPct - playoffOdds       // + = performing above standing, − = below
level = (playoffOdds + allPlayPct) / 2

if gap >  BAND  → Unlucky      (roster/performance ahead of standing → buy window)
if gap < -BAND  → Riding luck  (standing ahead of performance → sell high)
else (on the diagonal band):
    if level >= LEVEL_CUT        → Contender
    if level <= 100 - LEVEL_CUT  → Rebuild
    else                         → On pace
```
**Locked constants (user-tuned 2026-07):** `BAND = 9` (pts), `LEVEL_CUT = 60` (%).
These are the shipped defaults; keep them as named constants (candidates for the future
league/user config seed, per the architecture's tuning-constants note). The prototype
exposes them as live tweaks (`postureBand`, `levelCut`) — that panel is a tuning aid, not
a shipped control.

### Tone mapping (posture → color; reserved posture palette)
Contender → green `#37d9a0` · Unlucky → blue `#5aa0f5` · On pace → grey `#98a2b2` ·
Riding luck → amber `#f5b13b` · Rebuild → coral `#fb6f8c`.

### Posture map rendering
Scatter plot: dot at (X = playoff odds, Y = all-play %, Y inverted so high sits at top),
a drawn **diagonal** (y = x) as the "On pace" line, the region **above** the line tinted
Unlucky-blue and **below** tinted Riding-luck-amber, corners labeled
Contender / Unlucky / Rebuild / Riding luck. Keep the derivation in **one helper** so map,
chips (Teams), and team detail all read the same rule.

**Remaining posture TODOs:** none for the label rule. (Optional future: decide whether to
offer `true_rank` as an alternate Y-axis.)

### Watch game — 🟡 DEFINED RULE (§4.3)
A non-your game on the slate is flagged **"watch"** when its outcome swings **your** playoff
odds more than any other game, and by at least a floor.
```
for each game g not involving me:
  swing(g) = | myPlayoffOdds(g.home wins) − myPlayoffOdds(g.away wins) |   // from bracket_sim
watch = argmax_g swing(g),  flagged only if max swing >= WATCH_MIN
```
**Locked constant:** `WATCH_MIN = 2` (pts of playoff-odds swing). At most one game flagged
(the single most impactful) so it stays special. Real implementation: re-run / condition
`bracket_sim` on each outcome to get `myPlayoffOdds` under each result; the prototype mocks
`swing` deterministically. Surface the swing magnitude in the callout ("moves your odds ±X pts").

### Waiver thinness tiers — 🟡 DEFINED RULE (§4.2)
Measured **within the wire against an absolute startable line — NOT against rostered
players** (rostered are better by definition, which made everything read THIN). Count free
agents at the position who clear a position-specific weekly-points bar:
```
viable = count(freeAgents[pos] where weekly_proj >= STREAM_LINE[pos])
DEEP if viable >= 3,  STREAMABLE if 1–2,  THIN if 0
```
**Locked constants (prototype-tuned):** `STREAM_LINE = { QB:14, RB:8, WR:8, TE:6.5 }` weekly
points. These are streamer/startable bars, **league- & scoring-relative — tune per league**
(candidate for the config seed). Colors: DEEP green, STREAMABLE grey, THIN amber.
> Note: real waiver depth needs the **full free-agent pool** (now in V1 scope — the earlier
> V2 note is outdated). The prototype approximates FAs as undrafted players from a finite
> pool, so its absolute levels are illustrative; the *rule* is what transfers.

---

## 6. Forward-only fields (🔵) — wire now, gate the live read

`market_vor` and its `trade_gap` are **cross-time by construction right now**: rosters are
frozen at 2025 wk4, but the LeagueLogs market is live 2026 and can't be backdated
(`is_cross_time` / `market_season` / `has_production_vor` are first-class columns).

- **Wire the fields** (MKT VOR column, the Market trend line, the BUY/HOLD/SELL lean).
- **Gate the live trade call**: surface it as validation/POC until the season rolls to
  2026 and production + market share a time world. Respect `is_cross_time` — never fuse a
  cross-time gap into a confident "make this trade" verdict.

---

## 7. Recommended build order (slice-by-slice against the prototype)

Build one surface at a time, each checkable against its prototype screen. Suggested order,
easiest-map first so the seam and adapter patterns get established early:

1. **Players table + Player card** — richest 1:1 map (`production_vor`, `market_vor`,
   `ros_synthesis`, `player_signal`). Establishes the read-shapes and the VOR/trend seam.
2. **Manager Dossier** — trivial map (`manager_dossiers`), good early win.
3. **Teams + Team detail** — `positional_depth`, all-play, roster, dossier button.
4. **League** — `bracket_odds`, `true_rank`, positional aggregation, posture derivation
   (resolve §5 first).
5. **Matchups** — `bracket_sim` + `projection_consensus`; two-pane on web.

Each slice: replace the mock object for that screen with a `queries.js` read of the shape
in §4, confirm the screen matches the prototype, move on. The week switcher (§3) should be
wired early (step 1–2) since every derived read is `as_of_week`-parameterized.
