# Handoff: Gridiron — fantasy football league-management app

## Overview
Gridiron is a fantasy-football analytics app whose thesis is that **winning your league is
about managing your specific team in your specific league** — not just collecting the best
players. It surfaces league-winning *signal*: how your team is trending, where your real
weaknesses are, what your opponents look like, and when to act (or not).

This bundle contains two design references — a **mobile** app and a **web** app — that share
one data model and one visual system. They cover four surfaces (League, Matchups, Teams,
Players) plus four detail views (Team, Player, Matchup, Manager Dossier).

## About the design files
The files in this bundle are **design references created in HTML** — prototypes showing the
intended look and behavior. They are **not production code to copy directly.** The task is to
**recreate these designs in the target codebase** — which already exists: a **React + Vite +
DuckDB-WASM** front-end (see the project's `application/frontend/` and
`TECHNICAL_ARCHITECTURE.md`). Use that stack's established patterns: views stay pure
renderers, and **all data access goes through `src/queries.js`** (the documented seam).

The prototypes are authored as "Design Components" — a single HTML file each, with the UI as
inline-styled markup and the data/logic in one class. That structure is a prototyping
convenience; in the real app, the markup becomes React components and the logic class's
`renderVals()` object becomes `queries.js` reads.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions are all specified and
intentional. Recreate the UI faithfully using the codebase's libraries. The one exception is
**data values**, which are mock — the real values come from the backend per `DATA_CONTRACT.md`.

## ⭐ Start with the DATA CONTRACT
`DATA_CONTRACT.md` (in this folder) is the most important document. It maps every visual to
the real backend entity that feeds it (`production_vor`, `market_vor`, `ros_synthesis`,
`player_signal`, `bracket_odds`, `true_rank`, `positional_depth`, `manager_dossiers`, …),
flags the few derivations and TODOs, and recommends a slice-by-slice build order. Read it
before implementing — it turns "match my data to these screens" from guesswork into a table.

---

## Screens / Views

### Persistent chrome
- **Mobile:** top header (brand, league switcher, week switcher) that persists across tabs +
  bottom tab bar (League / Matchups / Teams / Players) with line-icon glyphs (trophy / crossed
  swords / clipboard / helmet).
- **Web:** single top bar — brand + league switcher (left), prominent centered segmented tabs
  with the same glyphs (center), week switcher + avatar (right).
- League + week switchers are always reachable and persist across tabs.

### League — "whole league at a glance"
- **Mobile:** vertical stack — Your Race band → Playoff Picture → Posture Map → Positional Talent → (standings live on Teams).
- **Web:** Your Race as a full-width band, then a **3-column dashboard**: Playoff Picture · Posture Map · Positional Talent.
- **Your Race:** playoff chance (big), seed, "top 6 advance", magic number, and this-week game.
- **Playoff Picture:** 10 teams ranked by playoff odds, a drawn **playoff line** after seed 6, magic-number subline, and a **playoff-chance trendline** (sparkline) per team.
- **Posture Map:** quadrant scatter, X = standing (losing↔winning), Y = true rank (roster strength). Four labeled quadrants (Unlucky / Contender / Rebuild / Riding luck). Dots colored by posture; tap → team.
- **Positional Talent:** toggle QB/RB/WR/TE; per-team Market-VOR bars showing who controls each position; a **Waiver Wire** strip (best available + THIN/STREAMABLE/DEEP) that taps through to the filtered Players list.

### Matchups
- **Mobile:** the week's slate as head-to-head cards; your game pinned + highlighted; a "watch" game callout; tap → matchup detail.
- **Web:** **two-pane** — slate list (left), selected game's full breakdown (right). Selecting a row swaps the right pane; your game selected by default.
- **Matchup detail:** head-to-head win prob; **Score Range** (each team's 25–75 band with median tick, same scale — overlap = upset room); per-starter **range gauges** (median tick inside 25–75, wider = more volatile); Starters + Bench.

### Teams
- Standings table: rank, team, owner, record, **true record** (all-play W-L), posture chip, playoff % + **trendline**. Tap → team detail.

### Team detail
- Header + 4 stat blocks (Record, True Rec, Playoff %, Pts/Wk); this-week matchup bar (→ matchup detail);
- **Positional Depth** — per position, Market-VOR bar with league-median tick + SURPLUS/EVEN/GAP chip + league rank;
- **Manager Dossier** button → dossier screen;
- **Starters + Bench** with a **PROD VOR / MKT VOR toggle**; each row shows value + a 5-week trend sparkline + delta; tap a player → player card.

### Players
- Table anchored on **VOR**, split into **PROD** (default sort) and **MKT** columns; **BULL / BEAR / SIT** sortable columns; position filter + Available (waivers) toggle. Tap → player card.

### Player card
- Header (pos · team · proj) + status ("On your roster" / "Available" / "Rostered · X");
- **Value·VOR** — Production + Market as trend lines with value + delta, and a **BUY / HOLD / SELL** trade lean with a one-line why;
- **Opportunity** — Quality, Volume (share), Trust (direction + reliability) as three separate axes + a points-vs-profile companion read;
- **ROS Outcome Shape** — Bull / Bear / Situation 1–10 grades with a signal-confidence flag and a narrative "why".

### Manager Dossier
- Headline (style) + five tendency fields (Waiver/FAAB, Trade Tendency, Positional Lean, Roster Construction, Edge/Blind Spot) + a **Signal Depth** footer (HIGH/MED/THIN badge, leagues/seasons/moves counts, trust sentence). Copy is tendencies-not-verdicts, confidence gated on signal depth.

---

## Interactions & Behavior
- **Tab nav:** switches the four surfaces; state persists (switchers stay put).
- **Drill-downs:** standings row / posture dot → team; matchup card → matchup detail; player row → player card; team's dossier button → dossier. "‹ Back" returns.
- **Mobile detail views** replace the content area (full-screen); **web detail views** are centered at a readable max-width; **web Matchups** is a persistent two-pane (no navigation to see a breakdown).
- **Toggles/sorts:** Players sort columns (PROD/MKT/BULL/BEAR/SIT); roster metric toggle (PROD/MKT VOR); positional-talent position toggle; players position + availability filters.
- **Week switcher** = season replay: selects the `as_of_week` slice; default latest, travels back only; applies across League + Team and persists across tabs.
- **Transitions:** screens fade/slide in (~0.22s ease). Sparklines are inline SVG polylines. No other motion.

## State Management
Mirrors the prototype logic class:
- `tab` (league/matchups/teams/players), `detail` ({type, name/id} or null),
- Players: `pos` filter, `avail` filter, `sort` key,
- League: `posLg` (positional-talent position),
- Team detail: `rosterMetric` (pvor/mvor),
- Web Matchups: `selMatch` (selected game),
- Global: `asOfWeek` (owned by the app shell; see the contract §3).

Data fetching: per `DATA_CONTRACT.md`, one read per surface through `queries.js`, parameterized by `asOfWeek`.

## Design Tokens
**Color**
- Canvas: `#0e1116` (content), `#0a0c10` (chrome/bars), `#0b0e13` (map well), `#0d1014` (web panels)
- Surfaces: `#141922` / `#141418` cards, borders `#1b2029` / `#2a3340` / `#232c38`
- Text: `#e9edf3` primary, `#c7cdd7` / `#aeb7c4` secondary, `#8892a2` / `#7a8493` muted, `#5b6472` / `#5f6b7a` faint
- **Brand / accent (violet):** `#8b80f9` primary, `#a99dff` light, `#4b4488` border, `#0e0b18` / `#140a0e` on-violet text. Used for brand, active tab, YOU, your-side of matchup bars, VOR, links.
- **Posture palette (reserved for posture + trend up/down only):** Contender/up `#37d9a0` (light `#5eead4`), Unlucky `#5aa0f5` (`#7cc9fb`), On pace `#98a2b2` (`#8296a0`), Riding luck/down `#f5b13b` (`#e0a94a`), Rebuild `#fb6f8c` (`#fb84a6`). Opponent side of matchup bars uses neutral steel `#5b6577` / `#9aa3b5` (deliberately NOT posture colors).
- Chip backgrounds are the posture color at ~13–14% alpha.

**Typography**
- UI: **Archivo** (400–900). Numbers/mono/labels: **IBM Plex Mono** (400–600).
- Scale (mobile): hero numerals 38–44px/800; section titles 20px/800; body 13–14px; labels 8.5–10.5px with 0.1–0.16em letter-spacing, uppercase, muted. Web nudges detail/stat numerals up (e.g. stat blocks ~16px, matchup win% ~30–32px).

**Radius:** cards 13–18px, chips/pills 999px, small controls 6–11px.
**Shadow:** ambient only — `0 14–40px … rgba(0,0,0,.16–.55)` on the app frame and hero cards.
**Spacing:** 8/10/12/16/20/26px rhythm; flex/grid with `gap`.

## Assets
No external images. Icons are **inline SVG** (line style, 1.6–1.8 stroke, `currentColor`):
trophy (League), crossed swords (Matchups), clipboard (Teams), football helmet (Players),
shield-check (Dossier), lock (was on the dossier gate — now removed). Sparklines/gauges are
inline SVG. Fonts load from Google Fonts (Archivo, IBM Plex Mono).

## Files
- `Gridiron - Mobile.dc.html` — mobile prototype (388px frame). All screens + detail views + working nav/sort/toggle/drill-down.
- `Gridiron - Web.dc.html` — web prototype (1280px shell). Same engine; desktop layouts + two-pane Matchups.
- `DATA_CONTRACT.md` — ⭐ per-visual field → backend entity mapping, flags, TODOs, build order.

Both prototypes are self-contained HTML (open directly in a browser). Their data lives in the
`renderVals()` method of the logic class — that method is the concrete list of every field the
UI consumes, and the contract names the real entity for each.

---

## Open decisions carried into the build (from `DATA_CONTRACT.md`)
- 🟡 **Posture** — defined (all-play % × playoff odds, band 9, level cut 60; `DATA_CONTRACT.md` §5).
- 🟡 **Waiver thinness** (STREAM_LINE per position) and **watch game** (WATCH_MIN swing) — both defined rules now (§5); constants are league-tunable.
- 🔵 **Market VOR / trade gap is forward-only** right now (cross-time: 2025 rosters × 2026
  market). Wire the fields; gate the live BUY/SELL call until the season rolls to 2026.
- Everything else maps directly to a shipped backend entity.
